# Entry point for Agent007Bot
print('Starting Agent007Bot...')